﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace St_Project
{
    public partial class productofsec : Form
    {
        public productofsec()
        {
            InitializeComponent();
        }
        int m = 0;
        int numofproduct = 20;


        private void CreateButton(string buttonText)
        {
            Button button = new Button();
            button.Size = new Size(230, 52);
            button.BackColor = Color.Lavender;
            button.ForeColor = Color.Black;
            button.Font = new Font("Arial", 16, FontStyle.Bold);
            button.Text = buttonText;
            button.Click += (sender, e) =>
            {
                                                                     //     ShowQuantity();    // or quantity
                label6.Text=button.Tag+""; // Tag =quantity
            };
            flowLayoutPanel1.Controls.Add(button);
        }
        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

                for (; m <= numofproduct; m++)
                {
                    CreateButton("Product" + m);
                }

        }


        //private void ShowQuantity()
        //{
        //    Form messageForm = new Form();
        //    messageForm.Text = "Quantity : ";
        //    messageForm.Width = 300;
        //    messageForm.Height = 150;

        //    Label label = new Label();
        //    label.Text = "50";
        //    label.Dock = DockStyle.Fill;
        //    label.TextAlign = ContentAlignment.MiddleCenter;

        //    messageForm.Controls.Add(label);
        //    messageForm.ShowDialog();
        //}


        private void button4_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            if (panel2.Visible == false)
            {
                panel2.Visible = true;
            }
            else
            {
                panel2.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
            if (panel1.Visible == false)
            {
                panel1.Visible = true;
            }
            else
            {
                panel1.Visible = false;
            }
        }
    }
}
