﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolBar;

namespace St_Project
{
    public partial class outofs : Form
    {
        public outofs()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }


        private void outofs_Load_1(object sender, EventArgs e)
        {

        }
        int i = 0;
        private void flowLayoutPanel1_Paint_1(object sender, PaintEventArgs e)
        {
            int numofoutproduct = 10;
            int productcounter = 5;//  quantity of one product

            for (; i < numofoutproduct; i++)
            {
                //  if (productcounter == 0)
                {
                    System.Windows.Forms.Button button = new System.Windows.Forms.Button();
                    button.Text = "Product" + (i + 1);
                     flowLayoutPanel1.Controls.Add(button);
                    button.Size = new Size(210, 52);
                    button.BackColor = Color.Lavender;
                    button.ForeColor = Color.Black;
                    button.Font = new Font("Arial", 16, FontStyle.Bold);

                    //button.Click += new System.EventHandler(but1_Click);


                }
                // else
                {

                }
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
