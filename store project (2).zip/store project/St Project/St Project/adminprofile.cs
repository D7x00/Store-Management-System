﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace St_Project
{
    public partial class adminprofile : Form
    {
        public adminprofile()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(panel1.Visible = true)
            {
                panel1.Visible = false;
                panel2.Visible = true;
               
            }
            else
            {
                panel1.Visible = true;
                panel2.Visible = false;
            }



        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
            panel4.Visible = false;
            usersform newForm7 = new usersform();
            this.Visible = false;
            newForm7.Show();
            //to return to admin home
            newForm7.FormClosed += (s, args) =>
            {
                this.Visible = true;
            };
        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
            panel4.Visible = false;
            repform newForm4 = new repform();
            this.Visible = false;
            newForm4.Show();
            //to return to admin home
            newForm4.FormClosed += (s, args) =>
            {
                this.Visible = true;
            };
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
                panel1.Visible = true;
                panel2.Visible = false;
           
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if(panel3.Visible == false)
            {
                panel3.Visible = true;
            }
            else
            {
                panel3.Visible = false;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
            panel4.Visible = false;
            notesform newForm2 = new notesform();
            this.Visible = false;
            newForm2.Show();
            //to return to admin home
            newForm2.FormClosed += (s, args) =>
            {
                this.Visible = true;
            };
        }

        private void adminprofile_Load(object sender, EventArgs e)
        {
          // panel1.Visible = true;
          // panel2.Visible = false; 
            panel3.Visible = false;
            panel4.Visible = false;
        }

        private void button10_Click(object sender, EventArgs e)
        {

        }
        int numofsection = 6;
        int i = 0;

        private void CreateButton(string buttonText)
        {
            Button button = new Button();
          
            button.Size = new Size(157, 163); 
            button.BackColor = Color.Lavender; 
            button.ForeColor = Color.Black; //PapayaWhip
            button.Font = new Font("Arial", 16, FontStyle.Bold);
            button.Text = buttonText;
        
            button.Click += (sender, e) =>
            {
                ShowresForm();
            };
            flowLayoutPanel1.Controls.Add(button);
        }

        private void ShowresForm()
        {
            productofsec newForm10 = new productofsec();
            this.Visible = false;
            newForm10.Show();
            //to return to admin home
            newForm10.FormClosed += (s, args) =>
            {
                this.Visible = true;
            };
        }

        int k = 1; // num of sections
        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
            for (; k <= 10; k++)
            {
                CreateButton("Section" + k);
            }

        }


        //         -------------------------------
        private void button10_Click_1(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
            panel4.Visible = false;
            outofs newForm1 = new outofs();
            this.Visible = false;
            newForm1.Show();
            //to return to admin home
            newForm1.FormClosed += (s, args) =>
            {
                this.Visible = true;
            };
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click_2(object sender, EventArgs e)
        {
            this.Close();
            Form1 logform = new Form1();
            logform.Show();
        }

        private void button10_MouseLeave(object sender, EventArgs e)
        {
            panel3.Visible = false;
        }

        private void button10_MouseHover(object sender, EventArgs e)
        {
       
        }

        private void panel2_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
            panel4.Visible = false;
        }

        private void adminprofile_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
            panel4.Visible = false;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
            panel4.Visible = false;
            settform newForm3 = new settform();
            this.Visible = false;
            newForm3.Show();
            //to return to admin home
            newForm3.FormClosed += (s, args) =>
            {
                this.Visible = true;
            };
        }

        private void button11_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
            if (panel4.Visible==false)
            { panel4.Visible = true; }  
            else
            { panel4.Visible = false; } 
        }
       
        private void button6_Click(object sender, EventArgs e)
        {
            string adminpasswd = "ss";
            panel3.Visible = false;
            panel4.Visible = false;
            string userInput = Interaction.InputBox("Enter Your Password ", "System Information", "");
            if (userInput == adminpasswd)
            {
                teamform newForm6 = new teamform();
                this.Visible = false;
                newForm6.Show();
                //to return to admin home
                newForm6.FormClosed += (s, args) =>
                {
                    this.Visible = true;
                };
            }
            else
            {
                MessageBox.Show("Incorrect Password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {
            panel3.Visible=false;
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
        string adminpasswd="ss";
        private void button15_Click(object sender, EventArgs e)
        {
            string userInput = Interaction.InputBox("Enter Your Password ", "System Information", "");
            if (userInput == adminpasswd)
            {
                managerform newForm9 = new managerform();
                this.Visible = false;
                newForm9.Show();
                //to return to admin home
                newForm9.FormClosed += (s, args) =>
                {
                    this.Visible = true;
                };
            }
            else
            {
                MessageBox.Show("Incorrect Password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
    }
}
