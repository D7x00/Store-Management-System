﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace St_Project
{
    public partial class teamform : Form
    {
        public teamform()
        {
            InitializeComponent();
        }

        int numofadmins = 10;
        int i = 0;
        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
            for (; i < numofadmins; i++)
            {
                Button button = new Button();
                button.Text = "Section" + (i + 1);
                flowLayoutPanel1.Controls.Add(button);
                button.Size = new Size(100, 70);
                button.BackColor = Color.PapayaWhip;
                button.ForeColor = Color.Black; //PapayaWhip
                button.Font = new Font("Arial", 16, FontStyle.Bold);




                //CheckBox checkBox1 = new CheckBox();
                //checkBox1.AutoSize = true;
                //checkBox1.Location = new System.Drawing.Point(146, 27);
                //checkBox1.Name = "checkBox " + i;
                //checkBox1.Size = new System.Drawing.Size(77, 170);
                //checkBox1.TabIndex = i;
                //checkBox1.Text = "ahmed";
                //checkBox1.BackColor = System.Drawing.Color.White  ;
                //checkBox1.UseVisualStyleBackColor = true;
                //checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
                //flowLayoutPanel1.Controls.Add(checkBox1);


            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
        
        int j = 0;
        int numofsup=6;
        private void flowLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {
            for (; j < numofsup; j++)
            {
                Button button = new Button();
                button.Text = "Section" + (j + 1);
                flowLayoutPanel2.Controls.Add(button);
                button.Size = new Size(100, 70);
                button.BackColor = Color.PapayaWhip;
                button.ForeColor = Color.Black; //PapayaWhip
                button.Font = new Font("Arial", 16, FontStyle.Bold);
            }
        }
    }
}
