﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace St_Project
{
    public partial class repform : Form
    {
        private int elapsedTime = 0;
        private const int totalTime = 60;
        public repform()
        {
            InitializeComponent();
        }

        private void repform_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(textBox1.Text);
            MessageBox.Show("The email has been copied successfully.");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
          //  textBox1.Text = "SARAAAA";
        }
        string adminpasswd = "sss";
        private void button2_Click(object sender, EventArgs e)
        {
            string userInput = Interaction.InputBox("Enter Your Password ", "System Information", "");
            if (userInput== adminpasswd )
            {
                elapsedTime = 0;
                panel2.Visible = true;
                timer1.Start();
            }
            else
            {
                MessageBox.Show("Incorrect Password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            elapsedTime++;
            if (elapsedTime >= totalTime)
            {
                timer1.Stop(); 
                panel2.Visible=false;
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
