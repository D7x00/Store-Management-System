﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace St_Project
{
    public partial class settform : Form
    {
    
        public settform()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button2.Visible = false;
            panel2.Visible = false;
            panel1.Visible = true;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            button2.Visible = true;
            panel2.Visible = false;
            panel1.Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string newname = button2.Text;
            button1.Visible = true;
            button2.Visible = true;
            panel1.Visible = false;
            panel2.Visible = false;
            
            if (textBox3.TextLength >= 4)
            {
                MessageBox.Show("Username updated Successfully.");
            }
            else
            {
                MessageBox.Show("Username must be at least 4 letters.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            button1.Visible = true;
            button2.Visible = true;
            panel1.Visible = false;
            panel2.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel1.Visible= false; panel2.Visible= false;
            button1 .Visible = true; button2 .Visible = true;
            string newadminpass = textBox1.Text;
            if(textBox1.TextLength>=8 && textBox1.Text == textBox2.Text)
            {
                MessageBox.Show("Password updated Successfully.");
            }
           else
            {
                if(textBox1.Text != textBox2.Text)
                {
                    MessageBox.Show("incorrect password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                MessageBox.Show("Password must be at least 8 letters.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel1.Visible = false; panel2.Visible = false;
            button1.Visible = true; button2.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button1.Visible = false;
            panel1.Visible = false;
            panel2.Visible = true;
        }
    }
}
