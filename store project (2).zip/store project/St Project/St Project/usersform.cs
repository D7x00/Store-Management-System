﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace St_Project
{
    public partial class usersform : Form
    {
        public usersform()
        {
            InitializeComponent();
        }
        int i = 0;
        int numofusers = 7;
        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
            for (; i < numofusers; i++)
            {
                Button button = new Button();
                button.Text = "Users" + (i + 1);
                flowLayoutPanel1.Controls.Add(button);
                button.Size = new Size(100, 70);
                button.BackColor = Color.Lavender;
                button.ForeColor = Color.Black; //PapayaWhip
                button.Font = new Font("Arial", 16, FontStyle.Bold);
            }
            }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
